class Place {
  String name;
  double price;
  String location;
  String description;
  String phone;
  int favorite;
  String? referenceId;
  String? imageUrl; // เพิ่มตัวแปรสำหรับ URL ของรูปภาพ

  static const collectionName = 'place';
  static const colName = 'name';
  static const colLocation = 'location';
  static const colDescription = 'description';
  static const colPhone = 'phone';
  static const colPrice = 'price';
  static const colFavorite = 'favorite';
  static const colImageUrl = 'imageUrl'; // เพิ่มคอนสแตนต์สำหรับชื่อคอลัมน์ของรูปภาพ

  Place({
    required this.name,
    required this.location,
    required this.description,
    required this.phone,
    required this.price,
    required this.favorite,
    this.referenceId,
    this.imageUrl, // เพิ่ม imageUrl ใน constructor
  });

  Map<String, dynamic> toMap() {
    var mapData = <String, dynamic>{
      colName: name,
      colLocation: location,
      colDescription: description,
      colPhone: phone,
      colPrice: price,
      colFavorite: favorite,
      colImageUrl: imageUrl, // เพิ่ม URL ของรูปภาพใน Map
    };
    return mapData;
  }

  Map<String, dynamic> toJson() {
    var jsonData = <String, dynamic>{
      colName: name,
      colLocation: location,
      colDescription: description,
      colPhone: phone,
      colPrice: price,
      colFavorite: favorite,
      colImageUrl: imageUrl, // เพิ่ม URL ของรูปภาพใน JSON
    };
    return jsonData;
  }
}
