import 'package:cloud_firestore/cloud_firestore.dart';
import 'model.dart';

class DatabaseHelper {
  final CollectionReference collection =
      FirebaseFirestore.instance.collection(Place.collectionName);

  Future<DocumentReference> insertPlace(Place place) {
    return collection.add(place.toJson());
  }

  void updatePlace(Place place) async {
    await collection.doc(place.referenceId).update(place.toJson());
  }

  void deletePlace(Place place) async {
    await collection.doc(place.referenceId).delete();
  }

  Stream<QuerySnapshot> getStream() {
    return collection.snapshots();
  }

  Future<QuerySnapshot> searchPlace(String keyValue) {
    return collection.where(Place.colName, isEqualTo: keyValue).get();
  }
}
