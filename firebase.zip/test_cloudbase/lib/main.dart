import 'package:flutter/material.dart';
import 'pages/Place.dart';
import 'database/model.dart';
//
// *** Edit #1 *** => import plug-in
//
import 'database/database_helper.dart';
import 'package:firebase_core/firebase_core.dart';
import 'pages/login.dart';

void main() async {
  //
  // *** Edit #2 *** => Modify main to init firebase plug-in
  //
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(apiKey: "AIzaSyAkeo50zxzMr_E_RcgnKrpUq3j_JSHjPHo",
     appId: "1:1032756403697:android:ee5070edf41073c1e6b850",
     messagingSenderId: "",
     projectId: "flutter-educate-e2293"),
  );
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      //
      // *** Edit #3 *** => modify calling ProductScreen (add new parameter)
      //
      home: LoginScreen(),
    );
  }
}
