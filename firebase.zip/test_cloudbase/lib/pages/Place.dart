import 'package:flutter/material.dart'; // นำเข้า Material Design สำหรับการสร้าง UI
import 'package:test_cloudbase/pages/search.dart'; // นำเข้าหน้า Search
import '../database/model.dart'; // นำเข้ารูปแบบข้อมูลที่ใช้ในฐานข้อมูล
import '../database/database_helper.dart'; // นำเข้าช่วยเหลือการเข้าถึงฐานข้อมูล
import 'package:cloud_firestore/cloud_firestore.dart'; // นำเข้าฐานข้อมูล Firebase Firestore
import 'dart:io'; // สำหรับจัดการไฟล์รูปภาพ
import 'package:image_picker/image_picker.dart'; // สำหรับการเลือกภาพจากแกลเลอรี
import 'package:firebase_storage/firebase_storage.dart'; // สำหรับอัปโหลดรูปภาพไปยัง Firebase Storage

class PlaceScreen extends StatefulWidget {
  PlaceScreen({Key? key, required this.dbHelper}) : super(key: key); // ตัวสร้างรับ DatabaseHelper
  final DatabaseHelper dbHelper; // ตัวแปรช่วยในการจัดการฐานข้อมูล
  @override
  _PlaceScreenState createState() => _PlaceScreenState(); // สร้าง State ของหน้าจอ
}

class _PlaceScreenState extends State<PlaceScreen> {
  List<Place> places = []; // รายการของสถานที่พัก

  Future<dynamic> _showConfirmDialog(BuildContext context, String confirmMessage) { 
    return showDialog( // แสดงหน้าต่างยืนยัน
      context: context,
      barrierDismissible: true, // ปิดหน้าต่างโดยคลิกข้างนอกได้
      builder: (BuildContext context) {
        return AlertDialog( // สร้างหน้าต่างแจ้งเตือน
          title: Text(confirmMessage), // ข้อความยืนยัน
          actions: [
            ElevatedButton( // ปุ่ม "Yes"
              onPressed: () {
                Navigator.pop(context, true); // ส่งค่ากลับเป็น true
              },
              child: const Text('Yes'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green), // สีปุ่มเขียว
            ),
            ElevatedButton( // ปุ่ม "No"
              onPressed: () {
                Navigator.pop(context, false); // ส่งค่ากลับเป็น false
              },
              child: const Text('No'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red), // สีปุ่มแดง
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) { 
    return Scaffold( // สร้างโครงหน้าจอหลัก
      appBar: AppBar(
        actions: [
          IconButton( // ปุ่มเพิ่มข้อมูลสถานที่พัก
            onPressed: () async {
              await ModalPlaceForm(dbHelper: widget.dbHelper).showModalInputForm(context); // แสดงฟอร์มเพิ่มสถานที่พัก
            },
            icon: const Icon(Icons.add_circle, size: 30), // ไอคอนเพิ่ม
          ),
          IconButton( // ปุ่มค้นหา
            onPressed: () {
              Navigator.of(context).push( 
                MaterialPageRoute(
                  builder: (context) => SearchPlace(dbHelper: widget.dbHelper), // เปิดหน้าค้นหา
                ),
              );
            },
            icon: const Icon(Icons.search, size: 30), // ไอคอนค้นหา
          ),
        ],
        title: const Text('สถานที่พักในจังหวัดตรัง'), // ชื่อหน้าจอ
        backgroundColor: Colors.deepPurple, // สีแถบ AppBar
      ),
      body: Container(
        decoration: BoxDecoration( // การตกแต่งพื้นหลัง
          gradient: LinearGradient(
            colors: [Colors.deepPurple.shade200, Colors.purple.shade100], // ไล่สีม่วง
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: StreamBuilder<QuerySnapshot>( // การดึงข้อมูลจาก Firestore แบบเรียลไทม์
          stream: widget.dbHelper.getStream(), // สตรีมข้อมูลจากฐานข้อมูล
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) { // ตรวจสอบว่ามีข้อมูลหรือไม่
              return const Center(child: CircularProgressIndicator()); // แสดงวงกลมหมุนเมื่อรอข้อมูล
            }
            places.clear(); // ล้างรายการก่อนเพิ่มข้อมูลใหม่
            for (var element in snapshot.data!.docs) { // วนลูปเอกสารที่ได้จากฐานข้อมูล
              places.add(Place( // เพิ่มข้อมูลสถานที่พักลงในรายการ
                name: element.get('name'), // ชื่อสถานที่พัก
                location: element.get('location'), // ที่อยู่
                description: element.get('description'), // รายละเอียด
                phone: element.get('phone'), // เบอร์โทรศัพท์
                price: element.get('price'), // ราคา
                favorite: element.get('favorite'), // บันทึกเป็นที่ชอบ
                referenceId: element.id, // รหัสอ้างอิง
              ));
            }
            return ListView.builder( // สร้างรายการแสดงผล
              itemCount: places.length, // จำนวนรายการ
              itemBuilder: (context, index) { // สร้างแต่ละรายการ
                return Dismissible( // ทำให้แต่ละรายการสามารถลบได้ด้วยการปัด
                  key: UniqueKey(),
                  background: Container( // พื้นหลังแสดงเมื่อปัดเพื่อจะลบ
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete, color: Colors.white, size: 30), // ไอคอนลบ
                  ),
                  onDismissed: (direction) { // เมื่อลบ
                    if (direction == DismissDirection.endToStart) {
                      widget.dbHelper.deletePlace(places[index]); // ลบสถานที่พักจากฐานข้อมูล
                    }
                  },
                  confirmDismiss: (direction) async { // ยืนยันก่อนลบ
                    if (direction == DismissDirection.endToStart) {
                      return await _showConfirmDialog(context, "Delete"); // แสดงหน้าต่างยืนยัน
                    }
                    return false;
                  },
                  child: Card( // สร้างการ์ดแสดงข้อมูล
                    margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: ListTile( // สร้างไอเทมในรายการ
                      title: Text(places[index].name, style: const TextStyle(fontWeight: FontWeight.bold)), // ชื่อสถานที่พัก
                      subtitle: Text('Price: ${places[index].price.toString()}'), // ราคา
                      trailing: places[index].favorite == 1 ? const Icon(Icons.favorite, color: Colors.red) : null, // ไอคอนบันทึกเป็นที่ชอบ
                      onTap: () async { // เมื่อคลิกที่รายการ
                        var result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailScreen(placeDetail: places[index]), // เปิดหน้ารายละเอียดสถานที่พัก
                          ),
                        );
                        setState(() {
                          if (result != null) { // อัปเดตข้อมูลบันทึกเป็นที่ชอบ
                            places[index].favorite = result;
                            widget.dbHelper.updatePlace(places[index]);
                          }
                        });
                      },
                      onLongPress: () async { // เมื่อกดค้าง
                        await ModalEditPlaceForm(dbHelper: widget.dbHelper, editedPlace: places[index])
                            .showModalInputForm(context); // แสดงฟอร์มแก้ไข
                      },
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class DetailScreen extends StatelessWidget {
  const DetailScreen({Key? key, required this.placeDetail}) : super(key: key);

  final Place placeDetail;
//นี่คือการสร้างคลาส DetailScreen ซึ่งเป็น StatelessWidget ที่ใช้แสดงรายละเอียดของสถานที่พักplaceDetail เป็นพารามิเตอร์ที่เก็บข้อมูลของสถานที่พักในรูปแบบ Place
  @override
  Widget build(BuildContext context) {
    var result = placeDetail.favorite; //ในเมธอด build มีตัวแปร result ที่ถูกกำหนดค่าเริ่มต้นจากสถานะ favorite ของสถานที่พักนั้น
    return Scaffold(
      appBar: AppBar(
        title: Text(placeDetail.name),
        backgroundColor: Colors.deepPurple,
      ), //สร้าง Scaffold สำหรับหน้าจอ โดยมี AppBar และแสดงชื่อสถานที่พักใน placeDetail.name และกำหนดสีพื้นหลังเป็นสีม่วง
      body: Padding(
        padding: const EdgeInsets.all(16.0), //กำหนด body ของหน้าจอเป็น Padding และภายในใช้ Column เพื่อจัดเรียงเนื้อหาในแนวตั้ง โดยมีการตั้ง crossAxisAlignment เป็น start เพื่อจัดชิดซ้าย
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              placeDetail.location,
              style: TextStyle(fontSize: 18, color: Colors.black54),
            ),
            const SizedBox(height: 10),
            Text(
              placeDetail.description,
              style: TextStyle(fontSize: 18, color: Colors.black54),
            ),
            const SizedBox(height: 10),
            Text(
              placeDetail.phone,
              style: TextStyle(fontSize: 16, color: Colors.black),
            ),
            const SizedBox(height: 10),
            Text(
              'ราคา: ${placeDetail.price.toString()}', //แสดงราคาของสถานที่พักในรูปแบบข้อความ โดยใช้ .toString() แปลงราคาเป็นสตริง และใช้ TextStyle เพื่อเน้นตัวหนา
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: placeDetail.favorite == 1 ? Colors.blueGrey : Colors.redAccent,
                  ),
                  child: placeDetail.favorite == 1 ? const Text('ยกเลิก') : const Text('สนใจ'),
                  onPressed: () {
                    result = placeDetail.favorite == 1 ? 0 : 1;
                    Navigator.pop(context, result);
                  },
                ), //แสดงปุ่ม ElevatedButton ที่เปลี่ยนสีและข้อความตามสถานะ favorite ของสถานที่พัก (1 คือสนใจ, 0 คือไม่สนใจ)เมื่อกดปุ่มจะเปลี่ยนสถานะ result และใช้ Navigator.pop() เพื่อส่งค่ากลับไปยังหน้าจอก่อนหน้า
                ElevatedButton(
                  child: const Text('ปิด'),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class ModalPlaceForm {
  ModalPlaceForm({Key? key, required this.dbHelper});
  final DatabaseHelper dbHelper;
  String _name = '', _location = '', _description = '', _phone = '';
  double _price = 0;
  final int _favorite = 0;
  File? _image; // ตัวแปรสำหรับเก็บไฟล์รูปภาพที่ผู้ใช้เลือก
  //แสดงปุ่ม ElevatedButton ที่เปลี่ยนสีและข้อความตามสถานะ favorite ของสถานที่พัก (1 คือสนใจ, 0 คือไม่สนใจ)เมื่อกดปุ่มจะเปลี่ยนสถานะ result และใช้ Navigator.pop() เพื่อส่งค่ากลับไปยังหน้าจอก่อนหน้า
    Future<void> pickImage() async {
    final pickedImage = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      _image = File(pickedImage.path); // เก็บภาพที่เลือกไว้ในตัวแปร
    }
  }

  Future<String?> uploadImage(File imageFile) async {
    try {
      String fileName = 'places/${DateTime.now().millisecondsSinceEpoch.toString()}.jpg';
      Reference storageReference = FirebaseStorage.instance.ref().child(fileName);
      UploadTask uploadTask = storageReference.putFile(imageFile);
      TaskSnapshot taskSnapshot = await uploadTask;
      String downloadUrl = await taskSnapshot.ref.getDownloadURL();
      return downloadUrl; // คืน URL ของรูปภาพที่อัปโหลด
    } catch (e) {
      print('Error uploading image: $e');
      return null;
    }
  }
  Future<dynamic> showModalInputForm(BuildContext context) {
    return showModalBottomSheet(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(
                title: Center(
                  child: Text(
                    'ฟอร์มกรอกข้อมูลสถานที่พัก',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              _buildTextField('ชื่อสถานที่พัก', 'กรอกชื่อสถานที่พัก', (value) {
                _name = value;
              }),
              _buildTextField('ที่อยู่', 'กรอกที่อยู่ของสถานที่พัก', (value) {
                _location = value;
              }),
              _buildTextField('รายละเอียด', 'กรอกรายละเอียดสถานที่พัก', (value) {
                _description = value;
              }),
              _buildTextField('ช่องทางการติดต่อ', 'กรอกเบอร์โทรศัพท์', (value) {
                _phone = value;
              }),
              _buildTextField('ราคา', 'กรอกราคา', (value) {
                _price = double.parse(value);
              }),

              // ปุ่มเลือกภาพจากแกลเลอรี
              Container(
                margin: const EdgeInsets.all(15),
                child: ElevatedButton(
                  onPressed: pickImage, // เรียกฟังก์ชันเลือกภาพ
                  child: const Text('เลือกรูปภาพ'),
                ),
              ),

              if (_image != null) // แสดงภาพที่เลือกถ้ามี
                Container(
                  margin: const EdgeInsets.all(15),
                  child: Image.file(_image!),
                ),

              Container(
                margin: const EdgeInsets.all(20),
                child: ElevatedButton(
                  child: const Text('เพิ่ม'),
                  onPressed: () async {
                    String? imageUrl;
                    if (_image != null) {
                      imageUrl = await uploadImage(_image!); // อัปโหลดรูปภาพ
                    }

                    var newPlace = Place(
                      name: _name,
                      location: _location,
                      description: _description,
                      phone: _phone,
                      price: _price,
                      favorite: _favorite,
                      referenceId: null,
                      imageUrl: imageUrl, // เพิ่ม URL รูปภาพที่อัปโหลด
                    );
                    await dbHelper.insertPlace(newPlace).then((value) {
                      newPlace.referenceId = value.id;
                    });
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text('${newPlace.name} ถูกเพิ่มเรียบร้อยแล้ว...'),
                    ));
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTextField(String label, String hint, Function(String) onChanged) {
    return Container(
      margin: const EdgeInsets.all(15),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.deepPurple),
          ),
        ),
        onChanged: onChanged,
      ),
    );
  }
}

class ModalEditPlaceForm {
  ModalEditPlaceForm({Key? key, required this.dbHelper, required this.editedPlace});
  final DatabaseHelper dbHelper;
  final Place editedPlace;
  String _name = '', _location = '', _description = '', _phone = '';
  double _price = 0;
  int _favorite = 0;
  String? _referenceId;

  Future<dynamic> showModalInputForm(BuildContext context) {
    _name = editedPlace.name;
    _location = editedPlace.location;
    _description = editedPlace.description;
    _phone = editedPlace.phone;
    _price = editedPlace.price;
    _favorite = editedPlace.favorite;
    _referenceId = editedPlace.referenceId;

    return showModalBottomSheet(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(
                title: Center(
                  child: Text(
                    'ฟอร์มกรอกข้อมูลสถานที่พัก (แก้ไข)',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              _buildTextField('ชื่อสถานที่พัก', 'กรอกชื่อสถานที่พัก', (value) {
                _name = value;
              }, initialValue: _name),
              _buildTextField('ที่อยู่', 'กรอกรายที่อยู่', (value) {
                _location = value;
              }, initialValue: _description),
              _buildTextField('รายละเอียด', 'กรอกรายละเอียดสถานที่พัก', (value) {
                _description = value;
              }, initialValue: _location),
              _buildTextField('ช่องทางการติดต่อ', 'กรอกเบอร์โทรศัพท์', (value) {
                _phone = value;
              }, initialValue: _phone),
              _buildTextField('ราคา', 'กรอกราคา', (value) {
                _price = double.parse(value);
              }, initialValue: _price.toString()),
              Container(
                margin: const EdgeInsets.all(20),
                child: ElevatedButton(
                  child: const Text('อัปเดต'),
                  onPressed: () async {
                    var updatedPlace = Place(
                      name: _name,
                      location: _location,
                      description: _description,
                      phone: _phone,
                      price: _price,
                      favorite: _favorite,
                      referenceId: _referenceId,
                    );
                    dbHelper.updatePlace(updatedPlace);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text('${updatedPlace.name} ถูกอัปเดต...'),
                    ));
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTextField(String label, String hint, Function(String) onChanged, {String? initialValue}) {
    return Container(
      margin: const EdgeInsets.all(15),
      child: TextFormField(
        initialValue: initialValue,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Colors.deepPurple),
          ),
        ),
        onChanged: onChanged,
      ),
    );
  }
}