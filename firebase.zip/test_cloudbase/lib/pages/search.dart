import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:test_cloudbase/database/database_helper.dart';
import 'package:test_cloudbase/database/model.dart';

// ignore: must_be_immutable
class SearchPlace extends StatefulWidget {
  SearchPlace({Key? key, required this.dbHelper}) : super(key: key);
  DatabaseHelper dbHelper;

  @override
  _SearchPlaceState createState() => _SearchPlaceState();
}

class _SearchPlaceState extends State<SearchPlace> {
  String _searchValue = '';
  List<Place> resultProducts = [];
  // String name = '', description = '';
  // double price = 0.00;
  bool found = false;

  void _showResponse(QuerySnapshot response) {
    setState(() {
      if (response.docs.isNotEmpty) {
        found = true;
        resultProducts.clear();
        for (var element in response.docs) {
          resultProducts.add(Place(
              name: element.get('name'),
              location: element.get('location'),
              description: element.get('description'),
              phone: element.get('phone'),
              price: element.get('price'),
              favorite: element.get('favorite'),));
        }
      } else {
        found = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Container(
          width: double.infinity,
          height: 40,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Center(
            child: TextField(
              onChanged: (value) => _searchValue = value,
              decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.play_circle),
                    onPressed: () async {
                      await widget.dbHelper
                          .searchPlace(_searchValue)
                          .then((res) {
                        _showResponse(res);
                      });
                    },
                  ),
                  hintText: 'Search...',
                  border: InputBorder.none),
            ),
          ),
        ),
      ),
      body: found
          ? buildFoundList()
          : const Center(
              child: Text("Search Result (Not Found)"),
            ),
    );
  }

  Widget buildFoundList() {
    return ListView.builder(
        itemCount: resultProducts.length,
        itemBuilder: (context, index) {
          return Card(
              child: ListTile(
            title: Text('Name: ${resultProducts[index].name}'),
            subtitle: Text(
                'Description:  ${resultProducts[index].description}/ Price: ${resultProducts[index].price}/ Phone: ${resultProducts[index].phone}'),
          ));
        });
  }
}
