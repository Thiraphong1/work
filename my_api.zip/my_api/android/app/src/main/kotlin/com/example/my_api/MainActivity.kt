package com.example.my_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
