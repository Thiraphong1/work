import random

def get_user_choice():
    user_input = input("เลือก (ค้อน, กระดาษ, กรรไกร): ").lower()
    while user_input not in ["ค้อน", "กระดาษ", "กรรไกร"]:
        user_input = input("กรุณาเลือกอีกครั้ง (ค้อน, กระดาษ, กรรไกร): ").lower()
    return user_input

def get_ai_choice():
    return random.choice(["ค้อน", "กระดาษ", "กรรไกร"])

def determine_winner(user, ai):
    if user == ai:
        return "เสมอ!"
    elif (user == "rock" and ai == "กรรไกร") or (user == "กระดาษ" and ai == "ค้อน") or (user == "กรรไกร" and ai == "กระดาษ"):
        return "คุณชนะ!"
    else:
        return "AI ชนะ!"

def show_rules():
    print("กฎของเกมเป่ายิ้งฉุบ:")
    print("1. หิน ชนะ กรรไกร")
    print("2. กรรไกร ชนะ กระดาษ")
    print("3. กระดาษ ชนะ หิน ")

def play_game():
    print("ยินดีต้อนรับสู่เกมเป่ายิ้งฉุบ!")
    show_rules()
    
    user_score = 0
    ai_score = 0
    round_number = 1

    while True:
        print(f"รอบที่: {round_number}")
        user_choice = get_user_choice()
        ai_choice = get_ai_choice()
        print(f"AI เลือก: {ai_choice}")
        
        result = determine_winner(user_choice, ai_choice)
        print(result)

        if result == "คุณชนะ!":
            user_score += 1
        elif result == "AI ชนะ!":
            ai_score += 1
        
        print(f"คะแนนของคุณ: {user_score} | คะแนนของ BOT: {ai_score}")

        play_again = input("ต้องการเล่นอีกไหม? (ใช่/ไม่): ").lower()
        if play_again != "ใช่":
            break
        round_number += 1

play_game()
