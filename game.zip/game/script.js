let userScore = 0;
let aiScore = 0;

function getAIChoice() {
    const choices = ["ค้อน", "กระดาษ", "กรรไกร"];
    const randomIndex = Math.floor(Math.random() * choices.length);
    return choices[randomIndex];
}

function determineWinner(user, ai) {
    if (user === ai) {
        return "เสมอ!";
    } else if (
        (user === "ค้อน" && ai === "กรรไกร") ||
        (user === "กระดาษ" && ai === "ค้อน") ||
        (user === "กรรไกร" && ai === "กระดาษ")
    ) {
        userScore++;
        return "คุณชนะ!";
    } else {
        aiScore++;
        return "AI ชนะ!";
    }
}

function play(userChoice) {
    const aiChoice = getAIChoice();
    const result = determineWinner(userChoice, aiChoice);
    document.getElementById("result").innerText = `AI เลือก: ${aiChoice} - ${result}`;
    document.getElementById("scoreboard").innerText = `คะแนนของคุณ: ${userScore} | คะแนนของ AI: ${aiScore}`;
    
    // ตรวจสอบคะแนน
    if (userScore === 5 || aiScore === 5) {
        showWinner();
    }
}
function showWinner() {
    const winner = userScore === 5 ? "คุณชนะเกม!" : "AI ชนะเกม!";
    document.getElementById("popup-message").innerText = winner;
    document.getElementById("popup").style.display = "flex"; // แสดงป๊อปอัพ
}

function closePopup() {
    document.getElementById("popup").style.display = "none"; // ซ่อนป๊อปอัพ
}

function resetGame() {
    closePopup(); // ปิดป๊อปอัพ
    userScore = 0;
    aiScore = 0;
    document.getElementById("result").innerText = "";
    document.getElementById("scoreboard").innerText = `คะแนนของคุณ: ${userScore} | คะแนนของ AI: ${aiScore}`;
}
