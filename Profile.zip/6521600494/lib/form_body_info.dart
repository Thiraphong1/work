import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'validators.dart';


class FormBodyInfoPage extends StatefulWidget {
  const FormBodyInfoPage({Key? key}) : super(key: key);

  @override
  State<FormBodyInfoPage> createState() => _FormBodyInfoPageState();
}

class _FormBodyInfoPageState extends State<FormBodyInfoPage> {
  double _vs = 0, _vl = 0, _ki = 0;
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Enter Your Information'),
      ),
      body: Form(
        key: _formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.fromLTRB(22, 20, 20, 0),
              alignment: Alignment.topLeft,
              child: const Text('ค่าเเรงดันของเเหล่งจ่ายไฟ(Vs)'),
            ),
            Container(
              margin: const EdgeInsets.all(20),
              child: TextFormField(
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp('[0-9.-]')),
                  ],
                  decoration: InputDecoration(
                    labelText: 'กรุณากรอกข้อมูล',
                    hintText: 'กรุณากรอกข้อมูลค่าเเรงดันของเเหล่งจ่ายไฟ',
                    border: OutlineInputBorder(
                      borderSide:
                          const BorderSide(color: Colors.grey, width: 32.0),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                          color: Colors.blueAccent, width: 1.0),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  onChanged: (value) {
                    _vs = double.parse(value);
                  },
                  validator: Validators.compose([
                    Validators.required('required number [0-100]'),
                    Validators.min(0, 'required number more than 100 CM!')
                  ])),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(22, 20, 20, 0),
              alignment: Alignment.topLeft,
              child: const Text('ค่าเเรงดันที่หลอด LED ที่ต้องการ(VL)'),
            ),
            Container(
              margin: const EdgeInsets.all(20),
              child: TextFormField(
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp('[0-9.-]')),
                  ],
                  decoration: InputDecoration(
                    labelText: 'กรุณากรอกข้อมูล',
                    hintText: 'กรุณากรอกข้อมูลค่าเเรงดันที่หลอด LED',
                    border: OutlineInputBorder(
                      borderSide:
                          const BorderSide(color: Colors.grey, width: 32.0),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                          color: Colors.blueAccent, width: 1.0),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  onChanged: (value) {
                    _vl = double.parse(value);
                  },
                  validator: Validators.compose([
                    Validators.required('required number [0-100]'),
                    Validators.min(0, 'required number more than 100 CM!')
                  ])),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(22, 20, 20, 0),
              alignment: Alignment.topLeft,
              child: const Text('ค่ากระเเสที่หลอด LED ต้องการ(I)'),
            ),
            Container(
              margin: const EdgeInsets.all(20),
              child: TextFormField(
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp('[0-9.-]')),
                  ],
                  decoration: InputDecoration(
                    labelText: 'กรุณากรอกข้อมูล',
                    hintText: 'กรุณากรอกข้อมูลค่ากระเเสที่หลอด LED ต้องการ(I)หน่วยเป็นเเอมป์(A)',
                    border: OutlineInputBorder(
                      borderSide:
                          const BorderSide(color: Colors.grey, width: 32.0),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                          color: Colors.blueAccent, width: 1.0),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  onChanged: (value) {
                    _ki = double.parse(value);
                  },
                  validator: Validators.compose([
                    Validators.required('required number [0-100]'),
                    Validators.min(0, 'required number more than zero!')
                  ])),
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all<Color>(Colors.blue),
                      ),
                      child: const Text('Submit'),
                      onPressed: () {
                        // TODO: calculate BMI and show the result
                        if (_formKey.currentState != null &&
                            _formKey.currentState!.validate()) {
                          double R =
                              (_vs - _vl)/_ki;
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text('ค่าความต้านทานที่ต้องการ เท่ากับ',
                                    style: TextStyle(color: Colors.blue)),
                                content: Text(
                                    'ค่าที่ได้ : ${R.toStringAsFixed(2)}เเอมป์'),
                                actions: [
                                  TextButton(
                                    child: const Text('ตกลง'),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                ],
                              );
                            },
                          );
                        }
                        ;
                      },
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Expanded(
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all<Color>(Colors.red),
                      ),
                      child: const Text('Close'),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
