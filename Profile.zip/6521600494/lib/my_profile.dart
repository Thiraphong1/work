import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 1, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Widget tab1() {
    return const Column(
      children: [
        SizedBox(height: 25),
        Text(
          'ข้อมูลส่วนตัว',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
        ),
        SizedBox(height: 15),
        Divider(
          height: 5,
          thickness: 2.5,
          color: Colors.black,
        ),
        SizedBox(height: 15),
        CircleAvatar(
          backgroundImage: AssetImage('assets/images/sigma.jpg'),
          radius: 120,
        ),
        SizedBox(height: 25),
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(''),
                Icon(Icons.male_rounded,
                    size: 30, color: Color.fromARGB(255, 79, 45, 171)),
                SizedBox(width: 10),
                Text(
                  'ชื่อ-นามสกุล : ธีระพษ์ พยัคฆ์รังสี',
                  style: TextStyle(
                    fontSize: 20,
                    color: Color.fromARGB(255, 0, 0, 0),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.account_circle,
                    size: 30, color: Color.fromARGB(255, 25, 142, 130)),
                SizedBox(width: 10),
                Text(
                  'รหัสนิสิต : 6521600494',
                  style: TextStyle(
                      fontSize: 20, color: Color.fromARGB(255, 0, 0, 0)),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.phone_rounded,
                    size: 30, color: Color.fromARGB(255, 7, 3, 255)),
                SizedBox(width: 10),
                Text(
                  'เบอร์โทรศัพท์ : 0991283264',
                  style: TextStyle(
                      fontSize: 20, color: Color.fromARGB(255, 0, 0, 0)),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.email_rounded,
                    size: 30, color: Color.fromARGB(255, 7, 3, 255)),
                SizedBox(width: 10),
                Text(
                  'Email : thiraphong.p@ku.th',
                  style: TextStyle(
                      fontSize: 20, color: Color.fromARGB(255, 0, 0, 0)),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 1,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Developer'),
          bottom: TabBar(
            controller: _tabController,
            tabs: const [
              Tab(text: 'Developer'),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            tab1(),
          ],
        ),
      ),
    );
  }
} 