function showPayment(productName, price) {
    // เปลี่ยนหน้าไปยังหน้าชำระเงิน
    window.location.href = `payment.html?name=${encodeURIComponent(productName)}&price=${price}`;
}
// ฟังก์ชันแสดงป๊อปอัพ
function showModal() {
    document.getElementById('loading-spinner').style.display = 'block'; // แสดง loading spinner
    document.getElementById('modal-confirm').style.display = 'none'; // ซ่อนปุ่มตกลง
    setTimeout(() => {
        document.getElementById('loading-spinner').style.display = 'none'; // ซ่อน loading spinner
        document.getElementById('modal-confirm').style.display = 'block'; // แสดงปุ่มตกลง
    }, 2000); // 2000 ms = 2 วินาที
}

// ฟังก์ชันปิดป๊อปอัพ
function closeModal() {
    document.getElementById('myModal').style.display = 'none';
    goBack(); // กลับไปที่หน้าหลัก
}
